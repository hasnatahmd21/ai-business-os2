# AI Business OS — Project Package

This package has **two separate pieces** that work together but are not one
file — that's normal for this kind of product:

| File | What it is |
|---|---|
| `landing.html` | Your marketing/sales page (static — open it in any browser or host it anywhere) |
| `app.py` | The actual product — a Streamlit web app with the working dashboard/tools |
| `requirements.txt` | Python packages `app.py` needs |

The landing page's "Request Early Access" buttons are wired to open the
Streamlit app once you deploy it — see step 3 below.

---

## What changed from your original file

1. **Healthcare module disabled on purpose.** The original code classified
   patient "emergency" urgency from a symptom checklist and auto-generated
   treatment plans. That's not real clinical software — it's keyword
   matching — and if a buyer used it on real patients, a wrong
   classification could cause real harm. I replaced that logic with a
   stub that clearly refuses to give clinical output. If you want a real
   healthcare feature, it needs to be built with a licensed clinician and
   proper validation — not as a demo feature here.
2. Added honest labels to the MLOps registry and Finance/Fraud screens
   ("sample/demo data", "not licensed advice") since those numbers are
   illustrative, not live.
3. Everything else — Marketing, Sales Scoring, Content, Support, Knowledge
   Base, Customer Success, Finance calculators, Strategy simulations,
   Multi-Agent Coordinator, Prompt Engineer — is unchanged and was already
   built as transparent rule-based logic or real Gemini API calls.

## Important: I could not run this app myself

My environment has no internet access, so I could not `pip install
streamlit` or actually launch it here. I reviewed the code thoroughly
(structure, wiring, logic) and it looks sound, but **please test-run it
yourself locally before selling it** — see step 1.

---

## 1. Run it locally to test

```bash
pip install -r requirements.txt
streamlit run app.py
```

This opens the app in your browser at `http://localhost:8501`. Click
through every menu item once and confirm it behaves as expected.

You'll need a **Gemini API key** (free tier available) for the AI-powered
sections (Sales AI Assistant, the 25 Execution Systems). Get one at
[aistudio.google.com/app/apikey](https://aistudio.google.com/app/apikey)
and paste it into the sidebar, or check "Use Demo Mode" to see canned
responses without a key.

## 2. Deploy it so customers can use it

Easiest free option — **Streamlit Community Cloud**:

1. Put `app.py` and `requirements.txt` in a GitHub repo.
2. Go to [share.streamlit.io](https://share.streamlit.io), sign in with
   GitHub, click "New app", point it at your repo and `app.py`.
3. In the app's "Secrets" settings, add your Gemini key so you don't have
   to expose it to buyers:
   ```
   GEMINI_API_KEY = "your-key-here"
   ```
   (the code already reads this via `os.getenv("GEMINI_API_KEY")`).
4. Deploy — you'll get a URL like `https://your-app.streamlit.app`.

Other options if you outgrow the free tier: Render, Railway, or a small
VPS running `streamlit run app.py` behind a reverse proxy.

## 3. Connect the landing page to the app

Open `landing.html`, find this line near the bottom:

```js
const APP_URL = "";
```

Change it to your deployed URL:

```js
const APP_URL = "https://your-app.streamlit.app";
```

Now every "Request Early Access" / pricing button opens the live app in a
new tab.

## 4. Before you actually sell this

- **Access control**: right now, anyone with the URL can use the app and
  burn your Gemini API quota. Streamlit doesn't have built-in paywalls —
  you'll want at minimum a shared password (`st.text_input` gate at the
  top of `app.py`) or, for a real product, a proper auth + billing layer
  (e.g. Stripe Checkout gating access).
- **Rename the brand** throughout `app.py` and `landing.html` if
  "ViralCart" / placeholder names shouldn't appear for your real buyers.
- **Legal**: given the finance and business-risk features, consider a
  simple Terms of Use / disclaimer page saying this is a planning tool,
  not licensed financial, legal, or medical advice.
